package com.dyl.cloudtags;


/**
 * ������¼
 * @author dengyalan
 *
 */
public class SearchDataPojo {

	private String content = "";

	public String getContent() {
		return content;
	}

	public SearchDataPojo setContent(String content) {
		this.content = content;
		return this;
	}
}
